package com.employee.tax.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.tax.dao.EmployeeTaxDao;
import com.employee.tax.model.EmployeeTax;
import com.employee.tax.model.EmployeeTaxResponse;

@Service
public class EmployeeTaxServiceImp1 implements EmployeeTaxService {
	@Autowired
	EmployeeTaxDao empDao;
	@Override
	public void saveEmployee(EmployeeTax et) {
		empDao.empsave(et);
		
	}
@Override
public EmployeeTaxResponse getEmployeeTax(String empId) {
	EmployeeTaxResponse empRes=empDao.getEmployeeTax(empId);
	Double salYearly = empRes.getSalYearly();
	Double tax=0.0;
	Double appIncome=0.0;
	if(salYearly<=250000) {
		tax=0.0;
	}
	else if(salYearly>=250001 && salYearly <=500000) {
		appIncome=salYearly -250000;
		tax=0.05 * appIncome;
	}
	else if(salYearly>=500001 && salYearly <=1000000) {
		appIncome =salYearly -500000;
		tax=12500 +(0.10 *appIncome);
	}
	else {
		appIncome=salYearly-1000000;
		tax =112500+(0.02 * appIncome);
	}
	empRes.setTaxAmount(tax);
	if(salYearly >=2500000)
		empRes.setCess(0.02 * appIncome);
	return empRes;
	
	}
}

