package com.employee.tax.dao;

import com.employee.tax.model.EmployeeTax;
import com.employee.tax.model.EmployeeTaxResponse;

public abstract class EmployeeTaxDao {
	public abstract void empsave(EmployeeTax et);
	public abstract EmployeeTaxResponse getEmployeeTax(String empId);

}
