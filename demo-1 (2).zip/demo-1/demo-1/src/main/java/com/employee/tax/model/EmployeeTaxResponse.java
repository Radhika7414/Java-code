package com.employee.tax.model;

public class EmployeeTaxResponse {
	private String empCode;
	private String firstName;
	private String lastName;
	private Double salYearly;
	private Double taxAmount;
	private Double cess;
	public String getEmpCode() {
		return empCode;
	}
	public void setEmpCode(String empCode) {
		this.empCode = empCode;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Double getSalYearly() {
		return salYearly;
	}
	public void setSalYearly(Double salYearly) {
		this.salYearly = salYearly;
	}
	public Double getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(Double taxAmount) {
		this.taxAmount = taxAmount;
	}
	public Double getCess() {
		return cess;
	}
	public void setCess(Double cess) {
		this.cess = cess;
	}
	

}
