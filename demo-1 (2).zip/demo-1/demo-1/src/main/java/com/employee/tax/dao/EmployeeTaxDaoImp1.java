package com.employee.tax.dao;

import org.springframework.stereotype.Repository;

@Repository
public class EmployeeTaxDaoImp1 implements EmployeeTaxDao {
@Autowired
NamedParameterJdbcTemplate jdbcTemplateOne;
@Override
public void empsave(EmployeeTax et) {
	
try {
	MapSqlParameterSource params=new MapSqlParameterSource();
	
	params.addValue("FIRSTNAME", et.getFirstName());
	params.addValue("lastNAME", et.getLasttName());
	params.addValue("EMAIL", et.getEmail());
	params.addValue("PHONENUMBER", et.getPhoneNumber());
	params.addValue("DOJ", et.getDateOfJoining());
	params.addValue("SALARY", et.getSalary());
	
	jdbcTemplateOne.update(QueryConstants.saveEmployeeDetails,params);
}
catch(Exception e) {
	
}
}
	@Override
	public EmployeeTaxResponse getEmployeeTax(String empId) {
		MapSqlParameterSource params=new MapSqlParameterSource();
		params.addValue("Employee_ID",empId);
		List<EmployeeTaxResponse>empTaxList=jdbcTemplateOne.query(QueryConstants.getEmpTaxDetails,params, new RowMapper<EmployeeTaxResponse>() {
			@Override
			public EmployeeTaxResponse mapRow(Resultset rs,int rowNums)throws sqlException{
				EmployeeTaxResponse etr=new EmployeeTaxResponse();
				etr.setEmpCode(rs.getString("EMPLOYEE_ID"));
				etr.setFirstName(rs.getString("FIRSTNAME"));
				etr.setLastName(rs.getString("LASTNAME"));
				etr.setSalYearly(rs.getDouble("YEARLY_SALARY"));
				return.etr;
				
			}
});
		return empTaxList.get(0);
	
}
}
