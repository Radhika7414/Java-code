package com.employee.tax.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.tax.model.EmployeeTax;
import com.employee.tax.model.EmployeeTaxResponse;
import com.employee.tax.service.EmployeeTaxService;

@RestController
public class EmployeeTaxController {
	@Autowired
	public EmployeeTaxService empService;
	@PostMapping("/employees")
	public void createEmployee(@Validated @RequestBody EmployeeTax employee) {
		empService.saveEmployee(employee);
	}
	@GetMapping("/tax")
	public EmployeeTaxResponse getEmpTax(@PathVariable("empId") String empId) {
		return empService.getEmployeeTax(empId);
	}

}
