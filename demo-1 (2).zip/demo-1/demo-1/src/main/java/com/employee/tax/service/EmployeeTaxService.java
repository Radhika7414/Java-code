package com.employee.tax.service;

import com.employee.tax.model.EmployeeTax;
import com.employee.tax.model.EmployeeTaxResponse;

public interface EmployeeTaxService {
	public void saveEmployee(EmployeeTax et);
	public EmployeeTaxResponse getEmployeeTax(String empId);

}
